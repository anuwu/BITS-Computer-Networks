Steps to run the solution to Problem 2
1. Open three terminals
2. Run make in one of them
3. Run ./server in first terminal
4. Run ./relay in second terminal
5. Run ./client in third terminal
6. The desired logs are in the three terminals.
